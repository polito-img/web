/*
 * This file is part of pvqm_EM
 *
 * Copyright (C) 2014  Enrico Masala
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Enrico Masala   < masala _at-symbol_ polito dot it >
 *
 * The software has been written from scratch following the description in:
 * A.P. Hekstraa, J.G. Beerendsa, et al., "PVQM - A Perceptual Video Quality Measure", Signal Processing: Image Communication, vol. 17, n. 10, Nov 2002, pp. 781 - 798.
 *
 * Please note that the license of this software does not give you any additional rights regarding patents
 * that might cover algorithms implemented in this software. Please consult a professional in case you need advice.
 *
 * The software is available to the research community free of charge.
 * If you wish to use this software in your research, we kindly ask that you reference our papers listed below:
 *
 * Marcus Barkowsky, Enrico Masala, Glenn Van Wallendael, Kjell Brunnstrom, Nicolas Staelens, and Patrick Le Callet,
 * "Objective Video Quality Assessment - Towards large scale video database enhanced model development",
 * IEICE Transactions on Communications, Jan 2015 (accepted for publication)
 * (please update the citation information once the manuscript will be published)
 *
 * Further citation information, downloads, etc., can be found at:
 * http://media.polito.it/jeg
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include "tools.h"


//#define DEBUG
 
 
#define BLOCK 4096

char buffer[BLOCK];
char buffer_err[BLOCK];

unsigned char fbuf_orig[BLOCK];
unsigned char fbuf_dec[BLOCK];
unsigned char fbuf_err[BLOCK];


static imgYUV_t img_orig;
static imgYUV_t img_err;


void alloc_imgYUV(imgYUV_t *img, yuv_t type) {
	int pixels = img->size.w * img->size.h;
	int c_factor = 1;
	if (type == YUV_420)
		c_factor = 4;
	else if (type == YUV_422)
		c_factor = 2;
	else if (type == YUV_444)
		c_factor = 1;
	img->Y = (unsigned char *)malloc(sizeof(unsigned char)*pixels);
	if (!img->Y) { fprintf(stderr,"ERROR: Cannot allocate img.Y\n"); }
	img->U = (unsigned char *)malloc(sizeof(unsigned char)*pixels/c_factor);
	if (!img->U) { fprintf(stderr,"ERROR: Cannot allocate img.U\n"); }
	img->V = (unsigned char *)malloc(sizeof(unsigned char)*pixels/c_factor);
	if (!img->V) { fprintf(stderr,"ERROR: Cannot allocate img.V\n"); }
}

void free_imgYUV(imgYUV_t *img) {
	if (img->Y) free(img->Y);
	if (img->U) free(img->U);
	if (img->V) free(img->V);
}


char *FileFormatToString(fileformat_t v) {
	if (v == FORMAT_YUV420) {
		return "FORMAT_YUV420";
	} else if (v == FORMAT_YUV422) {
		return "FORMAT_YUV422";
	} else if (v == FORMAT_YUV444) {
		return "FORMAT_YUV444";
	} else if (v == FORMAT_UYVY) {
		return "FORMAT_UYVY";
	} else {
		return "unknown";
	}
}


