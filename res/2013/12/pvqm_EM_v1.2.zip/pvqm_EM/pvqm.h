/*
 * This file is part of pvqm_EM
 *
 * Copyright (C) 2014  Enrico Masala
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Enrico Masala   < masala _at-symbol_ polito dot it >
 *
 * The software has been written from scratch following the description in:
 * A.P. Hekstraa, J.G. Beerendsa, et al., "PVQM - A Perceptual Video Quality Measure", Signal Processing: Image Communication, vol. 17, n. 10, Nov 2002, pp. 781 - 798.
 *
 * Please note that the license of this software does not give you any additional rights regarding patents
 * that might cover algorithms implemented in this software. Please consult a professional in case you need advice.
 *
 * The software is available to the research community free of charge.
 * If you wish to use this software in your research, we kindly ask that you reference our papers listed below:
 *
 * Marcus Barkowsky, Enrico Masala, Glenn Van Wallendael, Kjell Brunnstrom, Nicolas Staelens, and Patrick Le Callet,
 * "Objective Video Quality Assessment - Towards large scale video database enhanced model development",
 * IEICE Transactions on Communications, Jan 2015 (accepted for publication)
 * (please update the citation information once the manuscript will be published)
 *
 * Further citation information, downloads, etc., can be found at:
 * http://media.polito.it/jeg
 *
 */

#ifndef __PVQM_H_
#define __PVQM_H_

#include "tools.h"

#define MAX(a,b)  ((a) > (b) ? (a) : (b))
#define MIN(a,b)  ((a) < (b) ? (a) : (b))
#define ABS(a)    ((a) < 0 ? -(a) : (a))

#define FALSE 0
#define TRUE 1

/////////////////////////////////
// Decide to use either float or double
//  Adjust functions accordingly
/////////////////////////////////

//#define USE_FLOAT
#ifdef USE_FLOAT
	typedef float val_t;
	#define POW(a,b)  powf((a),(b))
	#define SQRT(a)  sqrtf((a))
	#define LOG10(a)  log10f((a))
	#define PS "%f"
	#define PE "%.6e"
#else
	typedef double val_t;
	#define POW(a,b)  pow((a),(b))
	#define SQRT(a)  sqrt((a))
	#define LOG10(a) log10((a))
	#define PS "%lf"
	#define PE "%.13e"
#endif

/////////////////////////////////

typedef struct img444_s {
	val_t **P[3];
	pic_size_t size;
} img444_t;

typedef struct img444i_s {
	int **P[3];
	pic_size_t size;
} img444i_t;

typedef struct img1c_s {
	val_t **P;
	pic_size_t size;
} img1c_t;



typedef struct field_s {
	val_t top;
	val_t bot;
} field_t;

typedef struct field3c_s {
	val_t top[3];
	val_t bot[3];
} field3c_t;

typedef struct region_s {
	int L;
	int R;
	int T;
	int B;
} region_t;

typedef struct indic3c_s {
	val_t v[3];
} indic3c_t;


typedef struct pvqm_res_img_s {
	val_t e_aggregfield;
	val_t d;
	indic3c_t n_aggregfieldmin;
} pvqm_res_img_t;

typedef struct pvqm_input_s {
	int pic_n; // Input to the routine to compute PVQM
	int interlaced;  // Input flag to the routine to compute PVQM
	fileformat_t file_format;  // Input value to the routine to compute PVQM
	region_t region;  // Input to the routine to compute PVQM
} pvqm_input_t;

typedef struct pvqm_res_s {
	val_t E;
	val_t EI;
	val_t D;
	indic3c_t N;
	val_t DMOS_P;
	val_t DMOS_PI;
} pvqm_res_t;

typedef struct pvqm_debug_s {
	int active;  // flag
	char fnamebase[200];
} pvqm_debug_t;


val_t compute_pvqm(FILE *f_orig, FILE *f_err, int w, int h, pvqm_input_t *inp, pvqm_res_t *res, file_out_t *out, pvqm_debug_t *deb);
img444i_t * pvqm_img(imgYUV_t *img_orig, imgYUV_t *img_err, int t, pvqm_input_t *inp, img444i_t *x3_t_1, pvqm_res_img_t *re, pvqm_debug_t *deb);

img444_t *dup_img444(img444_t *img);
imgYUV_t *create_imgYUV(int w, int h, yuv_t type);
imgYUV_t *read_imgYUV420(FILE *fp, int w, int h);
imgYUV_t *read_imgYUV422(FILE *fp, int w, int h);
imgYUV_t *read_imgYUV444(FILE *fp, int w, int h);
imgYUV_t *read_imgUYVY(FILE *fp, int w, int h);

img444_t *create_img444(int w, int h);
void alloc_img444(img444_t *img);
void free_img444(img444_t *img);
void print_img444(img444_t *img);

img444i_t *create_img444i(int w, int h);
void alloc_img444i(img444i_t *img);
void free_img444i(img444i_t *img);
void print_img444i(img444i_t *img);

img1c_t *create_img1c(int w, int h);
void alloc_img1c(img1c_t *img);
void free_img1c(img1c_t *img);
void print_img1c(img1c_t *img);
void print_stat_img1c(char *str, img1c_t *img);


void precompute_weight_function_if_needed(int wi, int he, int interlaced);

void save_img1c_as_Y_in_YUV( img1c_t *img, char *fname, int stretch, val_t use_as_min, val_t use_as_max);
void save_img444_ch_c_as_Y_in_YUV( img444_t *img, int c, char *fname, int stretch, val_t use_as_min, val_t use_as_max);
void save_img444_as_YUV444( img444_t *img, char *fname, int stretch, val_t use_as_min, val_t use_as_max);
void save_img444i_as_YUV444( img444i_t *img, char *fname, int stretch, val_t use_as_min, val_t use_as_max);

void debug_img444i(char *name_img, int t, img444i_t *orig, img444i_t *dec, pvqm_debug_t *deb);

void debug_img444_mix(char *name_img, int t, img444_t *img, pvqm_debug_t *deb);
void debug_img444_mix_stretch(char *name_img, int t, img444_t *img, pvqm_debug_t *deb);
void debug_img444_c_mix_stretch(char *name_img, int t, int c, img444_t *img, pvqm_debug_t *deb);
void debug_img1c(char *name_img, int t, img1c_t *orig, img1c_t *dec, pvqm_debug_t *deb);
void debug_img1c_mix(char *name_img, int t, img1c_t *img, pvqm_debug_t *deb);
void debug_img1c_mix_stretch(char *name_img, int t, img1c_t *img, pvqm_debug_t *deb);

img444_t *upsample444_by_copy(imgYUV_t *in);
img444_t *upsample411_444_asH264(imgYUV_t *in);
img444i_t *upsampleYUV_444i_asH264(imgYUV_t *in);

img444i_t * A1i_horizontal_filter(img444i_t *in);
img444i_t * A2i_field_separation(img444i_t *in);
img1c_t * A31i_edginess(img444i_t *in, int interlaced);
img1c_t * A32_dilation_edginess(img1c_t *in);
img1c_t * A33_max_dev_mid_range_luminance(img1c_t *orig, img1c_t *err);
img1c_t * A34_normalized_change_edginess(img1c_t *x, img1c_t *y, img1c_t *dev);
img1c_t * A35_clipping_normalized_change_edginess(img1c_t *in);
val_t A36_A37_aggregation_over_fields(img1c_t *in, region_t *r, int interlaced);
val_t A4i_temporal_decorrelation_indicator(img444i_t *in_t, img444i_t *in_t_1, region_t *r, int interlaced);
img1c_t * A51i_maximum_color_saturation(img444i_t *orig, img444i_t *dec);
img444_t * A52i_normalized_color_error(img444i_t *orig, img444i_t *dec, img1c_t *sat);
indic3c_t * A53_A54_aggregation_over_fields(img444_t *in, region_t *r, int interlaced);

val_t A61_seq_aggr_luminance_edginess(val_t *v_e, int P);
val_t A61_NOCLIP_seq_aggr_luminance_edginess(val_t *v_e, int P);
val_t A61_CLIP(val_t E);
val_t A62_seq_aggr_decorrelation(val_t *v_d, int P_1);
indic3c_t *A63_seq_aggr_color_indicators(indic3c_t *v_n, int P_1);
val_t A64_predicted_DMOS(val_t EI, indic3c_t *N, val_t D);
val_t A64_NOCLIP_predicted_DMOS(val_t EI, indic3c_t *N, val_t D);
val_t A64_CLIP(val_t dmos_p);

#endif

