
PVQM Implementation by Enrico Masala, 2014
< masala _at-symbol_ polito dot it >

This software implements the PVQM video quality measure.

The software has been written from scratch following the description in:
A.P. Hekstraa, J.G. Beerendsa, et al., "PVQM - A Perceptual Video Quality Measure", Signal Processing: Image Communication, vol. 17, n. 10, Nov 2002, pp. 781-798

Please note that the license of this software does not give you any additional rights regarding patents
that might cover algorithms implemented in this software. Please consult a professional in case you need advice.

ACKNOWLEDGMENT
==============

The software is available to the research community free of charge.
If you wish to use this software in your research, we kindly ask that you reference our papers listed below:

Marcus Barkowsky, Enrico Masala, Glenn Van Wallendael, Kjell Brunnstrom, Nicolas Staelens, and Patrick Le Callet,
"Objective Video Quality Assessment - Towards large scale video database enhanced model development",
IEICE Transactions on Communications, Jan 2015 (accepted for publication)
(please update the citation information once the manuscript will be published)

Further citation information, downloads, etc., can be found at:
http://media.polito.it/jeg


COMPILE
=======

In Linux, just type make

In Windows, there is a Visual Studio project file, but it is not guaranteed to work since testing was limited. However, any C compiler should work.

TEST
====

A small example is provided to test that everything is working correctly.
After compiling (Debug mode for Windows), enter the test directory and run:

test.sh   in Linux
test.bat  in Windows


RUN
===

Just run the program executable to get the list of options:

Usage: ./pvqm_EM  refVideo procVideo h w format outFile

format: YUV420 or YUV422

Example:
./pvqm_EM referenceVideo.yuv processedVideo.yuv 144 176 YUV420 result

The number of frames will be automatically computed
A result_pvqm.csv file will be produced




