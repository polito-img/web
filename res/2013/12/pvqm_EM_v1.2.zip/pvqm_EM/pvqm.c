/*
 * This file is part of pvqm_EM
 *
 * Copyright (C) 2014  Enrico Masala
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Enrico Masala   < masala _at-symbol_ polito dot it >
 *
 * The software has been written from scratch following the description in:
 * A.P. Hekstraa, J.G. Beerendsa, et al., "PVQM - A Perceptual Video Quality Measure", Signal Processing: Image Communication, vol. 17, n. 10, Nov 2002, pp. 781 - 798.
 *
 * Please note that the license of this software does not give you any additional rights regarding patents
 * that might cover algorithms implemented in this software. Please consult a professional in case you need advice.
 *
 * The software is available to the research community free of charge.
 * If you wish to use this software in your research, we kindly ask that you reference our papers listed below:
 *
 * Marcus Barkowsky, Enrico Masala, Glenn Van Wallendael, Kjell Brunnstrom, Nicolas Staelens, and Patrick Le Callet,
 * "Objective Video Quality Assessment - Towards large scale video database enhanced model development",
 * IEICE Transactions on Communications, Jan 2015 (accepted for publication)
 * (please update the citation information once the manuscript will be published)
 *
 * Further citation information, downloads, etc., can be found at:
 * http://media.polito.it/jeg
 *
 */

/*
 * FIXES some BUGS found in the article. Clarifications were asked by email to the authors (response from andries.hekstra@nxp.com, May 23, 2008)
 * i.e. A.6.3: linear average over time (not Lebesgue-7)
 * i.e. A.4: percentage value: d = 100*( 1 - inner product )
 * i.e. A.4: denominator is missing  sqrt()
 */


#ifdef _WIN32
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include <float.h>

#include <sys/types.h>


#ifdef _MSC_VER

#ifndef M_PI
#define M_PI 3.14159265358979323846 
#endif

#define isnan(x) ((x) != (x))

int truncate(char *fname, int size) {
	FILE* f;
	if (size!=0) {
		fprintf(stderr, "ERROR: cannot truncate file to size != 0\n"); exit(2);
	}
	f = fopen(fname, "w");
	fclose(f);
	return 0;
}

#include <stdarg.h>
#define snprintf c99_snprintf

int c99_vsnprintf(char* str, size_t size, const char* format, va_list ap)
{
    int count = -1;

    if (size != 0)
        count = _vsnprintf_s(str, size, _TRUNCATE, format, ap);
    if (count == -1)
        count = _vscprintf(format, ap);

    return count;
}

int c99_snprintf(char* str, size_t size, const char* format, ...)
{
    int count;
    va_list ap;

    va_start(ap, format);
    count = c99_vsnprintf(str, size, format, ap);
    va_end(ap);

    return count;
}


#else
#include <unistd.h>
#endif // _MSC_VER



#include "pvqm.h"


static img1c_t *W = NULL;  // Precomputed weight function

static const int debug = 0;
static const int debug_img = 0;

#define FACTOR 100

static void upsample1x1_to_2x2(int **up, int **y, int w_small, int h_small);
static void upsample2x1_to_2x2(int **up, int **y, int w_small, int h_small);
static img444i_t *upsample420_444i_asH264(imgYUV_t *in);
static img444i_t *upsample422_444i_asH264(imgYUV_t *in);
static int **alloc_int2D(int w, int h);
static void free_int2D(int **p, int h);



val_t compute_pvqm(FILE *f_orig, FILE *f_err, int w, int h, pvqm_input_t *inp, pvqm_res_t *res, file_out_t *out, pvqm_debug_t *deb) {

	int t,P;
	int interlaced;
	val_t *v_e;
	val_t *v_d;
	indic3c_t *v_n;
	pvqm_res_img_t re;
	img444i_t *x3_t_1 = NULL;

	P = inp->pic_n;	
	interlaced = inp->interlaced;

	v_e = (val_t *)malloc(sizeof(val_t)*P);
	if (!v_e) { fprintf(stderr,"ERROR: Cannot create v_e\n"); exit(1); }
	v_d = (val_t *)malloc(sizeof(val_t)*(P-1+1));
	if (!v_d) { fprintf(stderr,"ERROR: Cannot create v_d\n"); exit(1); }
	v_n = (indic3c_t *)malloc(sizeof(indic3c_t)*(P-1+1));
	if (!v_n) { fprintf(stderr,"ERROR: Cannot create v_n\n"); exit(1); }

	fprintf(out->fout_pvqm, "frame,e,d,n(c=1),n(c=2)\n");

	for (t=0; t<P; t++) {
		imgYUV_t *orig = NULL;
		imgYUV_t *err = NULL;
		img444i_t *x3;

		if (inp->file_format == FORMAT_YUV420) {
			orig = read_imgYUV420(f_orig, w, h);
			err  = read_imgYUV420(f_err, w, h);
		} else if (inp->file_format == FORMAT_YUV422) {
			orig = read_imgYUV422(f_orig, w, h);
			err  = read_imgYUV422(f_err, w, h);
		} else if (inp->file_format == FORMAT_YUV444) {
			orig = read_imgYUV444(f_orig, w, h);
			err  = read_imgYUV444(f_err, w, h);
		} else if (inp->file_format == FORMAT_UYVY) {
			orig = read_imgUYVY(f_orig, w, h);
			err  = read_imgUYVY(f_err, w, h);
		}

		x3 = pvqm_img( orig, err, t, inp, x3_t_1, &re, deb);

		if (t == 0) {
			v_d[t] = -1e6;
		} else {
			v_d[t] = re.d;
		}
		v_e[t] = re.e_aggregfield;
		v_n[t].v[1] = re.n_aggregfieldmin.v[1]; // U component (c=1)
		v_n[t].v[2] = re.n_aggregfieldmin.v[2]; // V component (c=2)

		if (deb->active) {
			printf("INFO: t= %3d  e[t]: "PS"\n",t, v_e[t]);
			printf("INFO: t= %3d  d[t]: "PS"\n",t, v_d[t]);
			printf("INFO: t= %3d  n[t](c=1): "PS"\n",t, v_n[t].v[1]);
			printf("INFO: t= %3d  n[t](c=2): "PS"\n",t, v_n[t].v[2]);
		}
		//fprintf(out->fout_pvqm, ""PE"  "PE"  "PE"  "PE"\n", v_e[t], v_d[t], v_n[t].v[1], v_n[t].v[2]);
		fprintf(out->fout_pvqm, "%d,"PE","PE","PE","PE"\n", t, v_e[t], v_d[t], v_n[t].v[1], v_n[t].v[2]);
		fflush(out->fout_pvqm);

		free_imgYUV(orig);
		free_imgYUV(err);
		if (x3_t_1) free_img444i(x3_t_1);
		x3_t_1 = x3;
	}
	if (!x3_t_1) { fprintf(stderr,"ERROR: Internal error: x3_t_1 should NOT be a null pointer!\n"); exit(2); }
	free_img444i(x3_t_1);
	
	//-----------------------------------
	// A.6: Aggregation to sequence level
	//-----------------------------------
	{
		// A.6.1: Aggregation of luminance edginess
		val_t E = A61_NOCLIP_seq_aggr_luminance_edginess(v_e, P);
		val_t EI = A61_CLIP(E);

		// A.6.2: Aggregation of decorrelation
		val_t D = A62_seq_aggr_decorrelation(v_d, P-1);

		// A.6.3: Aggregation of color indicators
		indic3c_t *N = A63_seq_aggr_color_indicators(v_n, P-1);

		// A.6.4: Predicted DMOS
		val_t DMOS_P = A64_NOCLIP_predicted_DMOS(EI, N, D);
		val_t DMOS_PI = A64_CLIP(DMOS_P);

		res->E = E;
		res->EI = EI;
		res->D = D;
		res->N.v[1] = N->v[1];
		res->N.v[2] = N->v[2];
		res->DMOS_P = DMOS_P;
		res->DMOS_PI = DMOS_PI;

		if (deb->active) {
			printf("FINAL E: "PS"\n", res->E);
			printf("FINAL EI: "PS"\n", res->EI);
			printf("FINAL D: "PS"\n", res->D);
			printf("FINAL N[c=1]: "PS"\n", res->N.v[1]);
			printf("FINAL N[c=2]: "PS"\n", res->N.v[2]);
			printf("FINAL DMOS_P: "PS"\n", res->DMOS_P);
			printf("FINAL DMOS_PI: "PS"\n", res->DMOS_PI);
		}

		// ----------- free ---------

		free(v_e);
		free(v_d);
		free(v_n);

		fprintf(out->fout_pvqm,"partial_values_E_D_N1_N2,%f,%f,%f,%f\n", E, D, N->v[1], N->v[2]);
		fprintf(out->fout_pvqm,"final_value,%f\n", DMOS_PI );

		return DMOS_PI;

	}
}


// Returns the x3 matrix (which is needed to compute the decorrelation index for the next frame)
img444i_t * pvqm_img(imgYUV_t *img_orig, imgYUV_t *img_err, int t, pvqm_input_t *inp, img444i_t *x3_t_1, pvqm_res_img_t *re, pvqm_debug_t *deb)
{
	// Upsampling 4:4:4
	//img444_t *x = upsample444_by_copy(img_orig);
	//img444_t *y = upsample444_by_copy(img_err);
	img444i_t *x;
	img444i_t *y;
	img444i_t *x2;
	img444i_t *y2;
	img444i_t *x3;
	img444i_t *y3;
	img1c_t *x_edge;
	img1c_t *y_edge;
	img1c_t *xIedge;
	img1c_t *yIedge;
	img1c_t *dev;
	img1c_t *e;
	img1c_t *e1;
	val_t e_aggregfield;
	val_t d;
	img1c_t *sat;
	img444_t *n;
	indic3c_t *n_aggregfieldmin;

	x = upsampleYUV_444i_asH264(img_orig);
	y = upsampleYUV_444i_asH264(img_err);

	if (debug_img) { debug_img444i("A0_upsampled", t, x, y, deb); }

	// A.1: Horizontal filter
	x2 = A1i_horizontal_filter(x);
	y2 = A1i_horizontal_filter(y);

	if (debug_img) { debug_img444i("A1_hor_filt", t, x2, y2, deb); }

	if (inp->interlaced) {
		// A.2: Fields
		x3 = A2i_field_separation(x2);
		y3 = A2i_field_separation(y2);
	} else {
		// dup_img444 is 3% of total execution time!! Eliminated to speed up the program
		//x3 = dup_img444(x2); y3 = dup_img444(y2);
		x3 = x2;
		y3 = y2;
	}
	//if (debug) { printf("MATRIX x3:\n"); print_img444i(x3); }
	//if (debug) { printf("MATRIX y3:\n"); print_img444i(y3); }

	if (debug_img) { debug_img444i("A2_field_sep", t, x3, y3, deb); }

	// A.3.1: Edginess
	x_edge = A31i_edginess(x3, inp->interlaced);
	y_edge = A31i_edginess(y3, inp->interlaced);

	if (debug_img) { debug_img1c("A31_edge", t, x_edge, y_edge, deb); }

	// A.3.2: Dilation of edginess
	xIedge = A32_dilation_edginess(x_edge);
	yIedge = A32_dilation_edginess(y_edge);
	//if (debug) { printf("MATRIX xIedge:\n"); print_img1c(xIedge); }
	//if (debug) { printf("MATRIX yIedge:\n"); print_img1c(yIedge); }

	if (debug_img) { debug_img1c("A32_edge_dilation", t, xIedge, yIedge, deb); }

	// A.3.3: Max dev from mid-range luminance
	dev = A33_max_dev_mid_range_luminance(xIedge, yIedge);

	if (debug_img) { debug_img1c_mix_stretch("A33_dev_mid_range_lum", t, dev, deb); }

	// A.3.4: Normalized change in edginess
	e = A34_normalized_change_edginess(xIedge, yIedge, dev);

	if (debug_img) { debug_img1c_mix_stretch("A34_normalized_edginess", t, e, deb); }

	// A.3.5: Clipping of normalized change in edginess
	e1 = A35_clipping_normalized_change_edginess(e);
	//if (debug) { printf("MATRIX e1:\n"); print_img1c(e1); }

	if (debug_img) { debug_img1c_mix_stretch("A35_normalized_edginess_clipped", t, e1, deb); }

	// A.3.6: Aggregation of edginess in top and bottom field
	// AND
	// A.3.7: Averaging of field indicator
	e_aggregfield = A36_A37_aggregation_over_fields(e1, &(inp->region), inp->interlaced);
	//if (debug) { printf("MATRIX W:\n"); print_img1c(W); }
	//if (debug) { printf("INFO: e1_aggregfield->top: "PS"\n", e1_aggregfield->top); printf("INFO: e1_aggregfield->bot: "PS"\n", e1_aggregfield->bot); }
	
	if (debug_img) { debug_img1c_mix_stretch("Weight function", t, W, deb); }


	// A.4: Temporal decorrelation indicator   (need previous frame)
	d = 0.0;
	if (x3_t_1) {
		// Not needed to compute if it is the first frame
		d = A4i_temporal_decorrelation_indicator(x3, x3_t_1, &(inp->region), inp->interlaced);
	}

	// A.5.1: Maximum color saturation
	sat = A51i_maximum_color_saturation(x3, y3);

	if (debug_img) { debug_img1c_mix("A51_max_color_sat", t, sat, deb); }

	// A.5.2: Normalized color error
	n = A52i_normalized_color_error(x3, y3, sat);

	if (debug_img) { debug_img444_c_mix_stretch("A52_normalized_color_err_Cb", t, 1, n, deb); }
	if (debug_img) { debug_img444_c_mix_stretch("A52_normalized_color_err_Cr", t, 2, n, deb); }

	// A.5.3: Aggregation over top and bottom field
	// AND
	// A.5.4: (only text in article) Minimum of field indicator
	n_aggregfieldmin = A53_A54_aggregation_over_fields(n, &(inp->region), inp->interlaced);
	//if (debug) { printf("INFO: n_top(c=1): "PS"  n_bot(c=1): "PS"   n_top(c=2): "PS" n_bot(c=2): "PS"\n",
	//		n_aggregfield->top[1], n_aggregfield->bot[1], n_aggregfield->top[2], n_aggregfield->bot[2] ); }

	re->e_aggregfield = e_aggregfield;
	re->d = d;
	re->n_aggregfieldmin.v[1] = n_aggregfieldmin->v[1];
	re->n_aggregfieldmin.v[2] = n_aggregfieldmin->v[2];


	// ============ Free All
	free_img444i(x);
	free_img444i(y);

	if (inp->interlaced) {
		// if interlaced, x2 and x3 refer to two memory areas allocated by two different malloc calls, otherwise they are the same as x3,y3
		free_img444i(x2);
		free_img444i(y2);
	}
	//free_img444(x3); --> This is returned to the calling routing, which will deallocate it
	free_img444i(y3);

	free_img1c(x_edge);
	free_img1c(y_edge);
	free_img1c(xIedge);
	free_img1c(yIedge);
	free_img1c(dev);
	free_img1c(e);
	free_img1c(e1);

	free_img1c(sat);
	free_img444(n);

	free(n_aggregfieldmin);
	// =====================
	return x3;
}


// #################################################
//  Utilities
// #################################################


void debug_img444i(char *name_img, int t, img444i_t *orig, img444i_t *dec, pvqm_debug_t *deb) {
	char fn[280];
	snprintf(fn, 280, "%s_444_%s_orig.yuv", deb->fnamebase, name_img);
	if (t==0) { if(truncate(fn, 0)!=0) {fprintf(stderr,"ERROR while truncating file\n"); exit(1);} }
	save_img444i_as_YUV444(orig, fn, FALSE, 0, 0);
	snprintf(fn, 280, "%s_444_%s_dec.yuv", deb->fnamebase, name_img);
	if (t==0) { if(truncate(fn, 0)!=0) {fprintf(stderr,"ERROR while truncating file\n"); exit(1);} }
	save_img444i_as_YUV444(dec, fn, FALSE, 0, 0);
}

void debug_img1c(char *name_img, int t, img1c_t *orig, img1c_t *dec, pvqm_debug_t *deb) {
	char fn[280];
	snprintf(fn, 280, "%s_420_%s_orig.yuv", deb->fnamebase, name_img);
	if (t==0) { if(truncate(fn, 0)!=0) {fprintf(stderr,"ERROR while truncating file\n"); exit(1);} }
	save_img1c_as_Y_in_YUV(orig, fn, FALSE, 0, 0);
	snprintf(fn, 280, "%s_420_%s_dec.yuv", deb->fnamebase, name_img);
	if (t==0) { if(truncate(fn, 0)!=0) {fprintf(stderr,"ERROR while truncating file\n"); exit(1);} }
	save_img1c_as_Y_in_YUV(dec, fn, FALSE, 0, 0);
}

void debug_img1c_mix(char *name_img, int t, img1c_t *img, pvqm_debug_t *deb) {
	char fn[280];
	snprintf(fn, 280, "%s_420_%s.yuv", deb->fnamebase, name_img);
	if (t==0) { if(truncate(fn, 0)!=0) {fprintf(stderr,"ERROR while truncating file\n"); exit(1);} }
	save_img1c_as_Y_in_YUV(img, fn, FALSE, 0, 0);
}

void debug_img1c_mix_stretch(char *name_img, int t, img1c_t *img, pvqm_debug_t *deb) {
	char fn[280];
	snprintf(fn, 280, "%s_420_%s.yuv", deb->fnamebase, name_img);
	if (t==0) { if(truncate(fn, 0)!=0) {fprintf(stderr,"ERROR while truncating file\n"); exit(1);} }
	save_img1c_as_Y_in_YUV(img, fn, TRUE, 0, 255);
}

void debug_img444_mix_stretch(char *name_img, int t, img444_t *img, pvqm_debug_t *deb) {
	char fn[280];
	snprintf(fn, 280, "%s_420_%s.yuv", deb->fnamebase, name_img);
	if (t==0) { if(truncate(fn, 0)!=0) {fprintf(stderr,"ERROR while truncating file\n"); exit(1);} }
	save_img444_as_YUV444(img, fn, TRUE, 0, 255);
}

void debug_img444_c_mix_stretch(char *name_img, int t, int c, img444_t *img, pvqm_debug_t *deb) {
	char fn[280];
	snprintf(fn, 280, "%s_420_%s.yuv", deb->fnamebase, name_img);
	if (t==0) { if(truncate(fn, 0)!=0) {fprintf(stderr,"ERROR while truncating file\n"); exit(1);} }
	save_img444_ch_c_as_Y_in_YUV(img, c, fn, TRUE, 0, 255);
}


imgYUV_t *create_imgYUV(int w, int h, yuv_t type) {
	imgYUV_t *res;
	res = (imgYUV_t *)malloc(sizeof(imgYUV_t));
	if (!res) { fprintf(stderr,"ERROR: Cannot create imgYUV\n"); exit(1); }
	res->size.w = w;
	res->size.h = h;
	res->format = type;
	alloc_imgYUV(res, type);
	return res;
}

imgYUV_t *read_imgYUV420(FILE *fp, int w, int h) {
	int j,k;
	imgYUV_t *img;
	unsigned char *buf;
	img = create_imgYUV(w, h, YUV_420);

	buf = (unsigned char *)malloc(sizeof(unsigned char)*w);
	if (!buf) { fprintf(stderr,"Cannot allocate buf\n"); exit(1); }
	for (j=0; j<h; j++) {
		if (fread(buf, w, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV420\n"); exit(1); }
		for (k=0; k<w; k++) {
			img->Y[j*w+k] = buf[k];
		}
	}
	for (j=0; j<h/2; j++) {
		if (fread(buf, w/2, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV420\n"); exit(1); }
		for (k=0; k<w/2; k++) {
			img->U[j*w/2+k] = buf[k];
		}
	}
	for (j=0; j<h/2; j++) {
		if (fread(buf, w/2, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV420\n"); exit(1); }
		for (k=0; k<w/2; k++) {
			img->V[j*w/2+k] = buf[k];
		}
	}
	free(buf);
	return img;
}

imgYUV_t *read_imgYUV422(FILE *fp, int w, int h) {
	int j,k;
	imgYUV_t *img;
	unsigned char *buf;
	img = create_imgYUV(w, h, YUV_422);

	buf = (unsigned char *)malloc(sizeof(unsigned char)*w);
	if (!buf) { fprintf(stderr,"Cannot allocate buf\n"); exit(1); }
	for (j=0; j<h; j++) {
		if (fread(buf, w, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV422\n"); exit(1); }
		for (k=0; k<w; k++) {
			img->Y[j*w+k] = buf[k];
		}
	}
	for (j=0; j<h; j++) {
		if (fread(buf, w/2, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV422\n"); exit(1); }
		for (k=0; k<w/2; k++) {
			img->U[j*w/2+k] = buf[k];
		}
	}
	for (j=0; j<h; j++) {
		if (fread(buf, w/2, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV422\n"); exit(1); }
		for (k=0; k<w/2; k++) {
			img->V[j*w/2+k] = buf[k];
		}
	}
	free(buf);
	return img;
}

imgYUV_t *read_imgYUV444(FILE *fp, int w, int h) {
	int j,k;
	imgYUV_t *img;
	unsigned char *buf;
	img = create_imgYUV(w, h, YUV_444);

	buf = (unsigned char *)malloc(sizeof(unsigned char)*w);
	if (!buf) { fprintf(stderr,"Cannot allocate buf\n"); exit(1); }
	for (j=0; j<h; j++) {
		if (fread(buf, w, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV444\n"); exit(1); }
		for (k=0; k<w; k++) {
			img->Y[j*w+k] = buf[k];
		}
	}
	for (j=0; j<h; j++) {
		if (fread(buf, w, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV444\n"); exit(1); }
		for (k=0; k<w; k++) {
			img->U[j*w+k] = buf[k];
		}
	}
	for (j=0; j<h; j++) {
		if (fread(buf, w, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgYUV444\n"); exit(1); }
		for (k=0; k<w; k++) {
			img->V[j*w+k] = buf[k];
		}
	}
	free(buf);
	return img;
}


imgYUV_t *read_imgUYVY(FILE *fp, int w, int h) {
	int j,k;
	imgYUV_t *img;
	unsigned char *buf;
	img = create_imgYUV(w, h, YUV_422);

	buf = (unsigned char *)malloc(sizeof(unsigned char)*(w*2));
	if (!buf) { fprintf(stderr,"Cannot allocate buf\n"); exit(1); }
	for (j=0; j<h; j++) {
		if (fread(buf, w*2, 1, fp)!=1)
			{ fprintf(stderr, "Error while reading in read_imgUYVY\n"); exit(1); }

		for (k=0; k<w/2; k++) {
			img->U[j*w/2+k] = buf[k*4];
			img->Y[j*w+(k*2)] = buf[k*4+1];
			img->V[j*w/2+k] = buf[k*4+2];
			img->Y[j*w+(k*2+1)] = buf[k*4+3];
		}
	}
	free(buf);
	return img;
}


img444_t *dup_img444(img444_t *img) {
	int i,j,c;
	img444_t *res;

	res = create_img444(img->size.w, img->size.h);

	for (c=0; c<3; c++) {
		for (j=0; j<img->size.h; j++) {
			for (i=0; i<img->size.w; i++) {
				res->P[c][j][i] = img->P[c][j][i];
			}
		}
	}
	return res;
}

img444_t *create_img444(int w, int h) {
	img444_t *res;
	res = (img444_t *)malloc(sizeof(img444_t));
	if (!res) { fprintf(stderr,"ERROR: Cannot create img444\n"); exit(1); }
	res->size.w = w;
	res->size.h = h;
	alloc_img444(res);
	return res;
}


void alloc_img444(img444_t *img) {
	int c,j;
	for (c=0; c<3; c++) {
		img->P[c] = (val_t **)malloc(sizeof(val_t *)* (img->size.h) );
		if (!img->P[c]) { fprintf(stderr,"ERROR: Cannot allocate img[c]\n"); exit(1); }
		for (j=0; j<img->size.h; j++) {
			img->P[c][j] = (val_t *)malloc(sizeof(val_t)* (img->size.w) );
			if (!img->P[c][j]) { fprintf(stderr,"ERROR: Cannot allocate img[c][j]\n"); exit(1); }
		}
	}
}

void free_img444(img444_t *img) {
	int c,j;
	for (c=0; c<3; c++) {
		for (j=0; j<img->size.h; j++) {
			if (img->P[c][j]) free(img->P[c][j]);
		}
		if (img->P[c]) free (img->P[c]);
	}
}


void print_img444(img444_t *img) {
	int c,j,i;
	for (c=0; c<3; c++) {
		for (j=0; j<img->size.h; j++) {
			for (i=0; i<img->size.w; i++) {
				printf("%.2f ",img->P[c][j][i]);
			}
			printf("\n");
		}
		printf("-------- end c=%d\n",c);
	}
}


img444i_t *create_img444i(int w, int h) {
	img444i_t *res;
	res = (img444i_t *)malloc(sizeof(img444i_t));
	if (!res) { fprintf(stderr,"ERROR: Cannot create img444i\n"); exit(1); }
	res->size.w = w;
	res->size.h = h;
	alloc_img444i(res);
	return res;
}


void alloc_img444i(img444i_t *img) {
	int c,j;
	for (c=0; c<3; c++) {
		img->P[c] = (int **)malloc(sizeof(int *)* (img->size.h) );
		if (!img->P[c]) { fprintf(stderr,"ERROR: Cannot allocate img[c]\n"); exit(1); }
		for (j=0; j<img->size.h; j++) {
			img->P[c][j] = (int *)malloc(sizeof(int)* (img->size.w) );
			if (!img->P[c][j]) { fprintf(stderr,"ERROR: Cannot allocate img[c][j]\n"); exit(1); }
		}
	}
}

void free_img444i(img444i_t *img) {
	int c,j;
	for (c=0; c<3; c++) {
		for (j=0; j<img->size.h; j++) {
			if (img->P[c][j]) free(img->P[c][j]);
		}
		if (img->P[c]) free (img->P[c]);
	}
}


void print_img444i(img444i_t *img) {
	int c,j,i;
	for (c=0; c<3; c++) {
		for (j=0; j<img->size.h; j++) {
			for (i=0; i<img->size.w; i++) {
				printf("%4d ",img->P[c][j][i]);
			}
			printf("\n");
		}
		printf("-------- end c=%d\n",c);
	}
}


img1c_t *create_img1c(int w, int h) {
	img1c_t *res;
	res = (img1c_t *)malloc(sizeof(img1c_t));
	if (!res) { fprintf(stderr,"ERROR: Cannot create img1c\n"); exit(1); }
	res->size.w = w;
	res->size.h = h;
	alloc_img1c(res);
	return res;
}

void alloc_img1c(img1c_t *img) {
	int j;
	img->P = (val_t **)malloc(sizeof(val_t *)* (img->size.h) );
	if (!img->P) { fprintf(stderr,"ERROR: Cannot allocate img->P\n"); exit(1); }
	for (j=0; j<img->size.h; j++) {
		img->P[j] = (val_t *)malloc(sizeof(val_t)* (img->size.w) );
		if (!img->P[j]) { fprintf(stderr,"ERROR: Cannot allocate img->P[j]\n"); exit(1); }
	}
}

void free_img1c(img1c_t *img) {
	int j;
	for (j=0; j<img->size.h; j++) {
		if (img->P[j]) free(img->P[j]);
	}
	if (img->P) free (img->P);
}

void print_img1c(img1c_t *img) {
	int j,i;
	for (j=0; j<img->size.h; j++) {
		for (i=0; i<img->size.w; i++) {
			printf("%.2f ",img->P[j][i]);
		}
		printf("\n");
	}
	printf("-------- end\n");
}

img444_t *upsample444_by_copy(imgYUV_t *in) {
	int i,j;
	int M = in->size.w;
	int N = in->size.h;
	img444_t *out;

	out = create_img444(in->size.w, in->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[0][j][i] = (val_t)(unsigned int) in->Y[j*M+i];
		}
	}
	for (j=0; j<N/2; j++) {
		for (i=0; i<M/2; i++) {
			out->P[1][j*2][i*2] = (val_t)(unsigned int) in->U[j*M/2+i];
			out->P[1][j*2+1][i*2] = (val_t)(unsigned int) in->U[j*M/2+i];
			out->P[1][j*2][i*2+1] = (val_t)(unsigned int) in->U[j*M/2+i];
			out->P[1][j*2+1][i*2+1] = (val_t)(unsigned int) in->U[j*M/2+i];

			out->P[2][j*2][i*2] = (val_t)(unsigned int) in->V[j*M/2+i];
			out->P[2][j*2+1][i*2] = (val_t)(unsigned int) in->V[j*M/2+i];
			out->P[2][j*2][i*2+1] = (val_t)(unsigned int) in->V[j*M/2+i];
			out->P[2][j*2+1][i*2+1] = (val_t)(unsigned int) in->V[j*M/2+i];
		}
	}
	return out;
}


static int **alloc_int2D(int w, int h) {
	int j;
	int **p;
	p = (int **)malloc(sizeof(int *)* (h) );
	if (!p) { fprintf(stderr,"ERROR: Cannot allocate int2D\n"); exit(1); }
	for (j=0; j<h; j++) {
		p[j] = (int *)malloc(sizeof(int)* (w) );
		if (!p[j]) { fprintf(stderr,"ERROR: Cannot allocate int2D\n"); exit(1); }
	}
	return p;
}

static void free_int2D(int **p, int h) {
	int j;
	for (j=0; j<h; j++) {
		if (p[j]) free(p[j]);
	}
	if (p) free(p);
}


void print_stat_img1c(char *str, img1c_t *img) {
	int j,i;
	int cnt=0;
	val_t max = -1e10;
	val_t min = 1e10;
	val_t sum = 0.0;
	for (j=0; j<img->size.h; j++) {
		for (i=0; i<img->size.w; i++) {
			sum += (img->P[j][i]);
			if (img->P[j][i] > max) max = img->P[j][i];
			if (img->P[j][i] < min) min = img->P[j][i];
			cnt++;
		}
	}
	printf("%s min: "PS", max: "PS", avg: "PS"\n", str, min, max, sum/cnt);
}


// #################################################
//  Load/save images
// #################################################

void save_img1c_as_Y_in_YUV( img1c_t *img, char *fname, int stretch, val_t use_as_min, val_t use_as_max) {
	int i,j;
	val_t max, min, fact;
	FILE *f;
	unsigned char *buf;
	// Open in append mode (no truncation)
	if ( (f = fopen(fname,"ab"))==NULL) { fprintf(stderr,"ERROR: Cannot open %s for writing!\n", fname); exit(3); }
	buf = (unsigned char *)malloc(sizeof(unsigned char)* img->size.w);
	if (!buf) { fprintf(stderr,"Cannot allocate buf\n"); exit(1); }

	max=-1e30;
	min=1e30;
	fact = 1.0;
	for (j=0; j<img->size.h; j++) {
		for (i=0; i<img->size.w; i++) {
			if (img->P[j][i] > max) max=img->P[j][i];		
			if (img->P[j][i] < min) min=img->P[j][i];		
		}
	}
	if (stretch) {
		if (max-min != 0) {
			fact = (use_as_max - use_as_min) / (max - min);
		}
		if (debug_img) printf("stretching factor for %s : %f\n", fname, fact);
	} else {
		if (min < 0 || max > 255) { printf("WARNING: save_img1c_as_Y_in_YUV %s :  min: %f max: %f but NOT stretching values\n",fname,min,max); }
	}

	for (j=0; j<img->size.h; j++) {
		for (i=0; i<img->size.w; i++) {
			val_t v;
			if (stretch) {
				v = use_as_min + (img->P[j][i]-min)*fact;
			} else {
				v = (unsigned char)(unsigned int) img->P[j][i];
			}
			// Clipping 0-255
			if (v > 255) v=255;
			if (v < 0) v=0;
			buf[i] = (unsigned char)(unsigned int)v;
		}
		fwrite(buf, img->size.w, 1, f);
	}

	for (i=0; i<img->size.w/2; i++) {
		buf[i]=128;  // No color for U and V	
	}
	for (j=0; j<img->size.h/2; j++) {
		fwrite(buf, img->size.w/2, 1, f);  // U
	}
	for (j=0; j<img->size.h/2; j++) {
		fwrite(buf, img->size.w/2, 1, f);  // V
	}
	fclose(f);
	free(buf);
}


void save_img444_ch_c_as_Y_in_YUV( img444_t *img, int c, char *fname, int stretch, val_t use_as_min, val_t use_as_max) {
	int i,j;
	img1c_t *pic = create_img1c(img->size.w, img->size.h);
	
	for (j=0; j<img->size.h; j++) {
		for (i=0; i<img->size.w; i++) {
			pic->P[j][i] = img->P[c][j][i];
		}
	}
	save_img1c_as_Y_in_YUV( pic, fname, stretch, use_as_min, use_as_max);
	free_img1c(pic);
}


void save_img444_as_YUV444( img444_t *img, char *fname, int stretch, val_t use_as_min, val_t use_as_max) {
	int i,j,c;
	val_t max, min, fact;
	FILE *f;
	unsigned char *buf;
	// Open in append mode (no truncation)
	if ( (f = fopen(fname,"ab"))==NULL) { fprintf(stderr,"ERROR: Cannot open %s for writing!\n", fname); exit(3); }
	buf = (unsigned char *)malloc(sizeof(unsigned char)* img->size.w);
	if (!buf) { fprintf(stderr,"Cannot allocate buf\n"); exit(1); }

	max=-1e30;
	min=1e30;
	fact = 1.0;
	for (c=0; c<3; c++) {
		for (j=0; j<img->size.h; j++) {
			for (i=0; i<img->size.w; i++) {
				if (img->P[c][j][i] > max) max=img->P[c][j][i];		
				if (img->P[c][j][i] < min) min=img->P[c][j][i];		
			}
		}
	}
	if (stretch) {
		if (max-min != 0) {
			fact = (use_as_max - use_as_min) / (max - min);
		}
	} else {
		if (min < 0 || max > 255) { printf("WARNING: save_img444_as_YUV444 %s :  min: %f max: %f but NOT stretching values\n",fname,min,max); }
	}

	for (c=0; c<3; c++) {
		for (j=0; j<img->size.h; j++) {
			for (i=0; i<img->size.w; i++) {
				val_t v;
				if (stretch) {
					v = use_as_min + img->P[c][j][i]*fact;
				} else {
					v = (unsigned char)(unsigned int) img->P[c][j][i];
				}
				// Clipping 0-255
				if (v > 255) v=255;
				if (v < 0) v=0;
				buf[i] = (unsigned char)(unsigned int)v;
			}
			fwrite(buf, img->size.w, 1, f);
		}
	}
	fclose(f);
	free(buf);
}

void save_img444i_as_YUV444( img444i_t *img, char *fname, int stretch, val_t use_as_min, val_t use_as_max) {
	int i,j,c;
	img444_t *out;
	out = create_img444(img->size.w, img->size.h);
	for (c=0; c<3; c++) {
		for (j=0; j<img->size.h; j++) {
			for (i=0; i<img->size.w; i++) {
				out->P[c][j][i] = (val_t)img->P[c][j][i];		
			}
		}
	}
	save_img444_as_YUV444(out, fname, stretch, use_as_min, use_as_max);
	free_img444(out);
}

// #################################################
//  Upsampling
// #################################################

static void upsample1x1_to_2x2(int **up, int **y, int w_small, int h_small) {
	int i,j;
	// y and up should be allocated externally
	// y :  dim is w_small * h_small
	// up : dim is (w_small*2) * (h_small*2)
	// -------------------------------------------------

	// For the upsampling algorithm, see doc JVT-I019     ftp://ftp3.itu.ch/av-arch/jvt-site/2003_09_SanDiego/JVT-I019.doc
	// Here we use the same filter for horiz and vert, since it keep the original values of pixels in half the positions

	// Output samples can be produced at positions 0..2N-1 for input samples at positions, 0..N-1, as follows.
	//
	// Samples at positions 2n are generated (x=0) as
	// y[n].
	// Samples at positions 2n+1 except positions 1, 2N-3 and 2N-1 are generated (x=1/2) as
	// ( - y[n-1] + 9 * y[n] + 9 * y[n+1] - y[n+2] + 8 ) >> 4.
	// Samples at position 1 are generated (interpolation, x= -1/2) as
	// ( 6 * y[0] + 12 * y[1] - 2 * y[2] + 8 ) >> 4.
	// Samples at position 2N-3 are generated (interpolation, x=1/2) as
	// ( - 2 * y[N-3] + 12 * y[N-2] + 6 * y[N-1] + 8 ) >> 4.
	// Samples at position 2N-1 are generated (extrapolation, x=1/2) as
	// ( 4 * y[N-3] - 16 * y[N-2] + 28 * y[N-1] + 8 ) >> 4.

	// Horizontal upsampling
	for (j=0; j<h_small; j++) {
		for (i=0; i<w_small; i++) {
			up[2*j][2*i] = y[j][i];
			if (i==0) {
				up[2*j][2*i+1] = ( ( 6 * y[j][0] + 12 * y[j][1] - 2 * y[j][2] + 8 ) >> 4 );
			} else if (i==w_small-2) {
				int N = w_small;
				up[2*j][2*i+1] = ( ( -2 * y[j][N-3] + 12 * y[j][N-2] + 6 * y[j][N-1] + 8 ) >> 4 );
			} else if (i==w_small-1) {
				int N = w_small;
				up[2*j][2*i+1] = ( ( 4 * y[j][N-3] - 16 * y[j][N-2] + 28 * y[j][N-1] + 8 ) >> 4 );
			} else {
				up[2*j][2*i+1] = ( ( - y[j][i-1] + 9 * y[j][i] + 9 * y[j][i+1] - y[j][i+2] + 8 ) >> 4 );
			}
			//up[2*j+1][2*i] = up[2*j][2*i];
			//up[2*j+1][2*i+1] = up[2*j][2*i+1];
		}
	}

	// Vertical upsampling
	for (i=0; i<w_small*2; i++) {
		for (j=0; j<h_small; j++) {
			// Here, points at even index are already ok
			if (j==0) {
				up[2*j+1][i] = ( ( 6 * up[0*2][i] + 12 * up[1*2][i] - 2 * up[2*2][i] + 8 ) >> 4 );
			} else if (j==h_small-2) {
				int N = h_small;
				up[2*j+1][i] = ( ( - 2 * up[(N-3)*2][i] + 12 * up[(N-2)*2][i] + 6 * up[(N-1)*2][i] + 8 ) >> 4 );
			} else if (j==h_small-1) {
				int N = h_small;
				up[2*j+1][i] = ( ( 4 * up[(N-3)*2][i] - 16 * up[(N-2)*2][i] + 28 * up[(N-1)*2][i] + 8 ) >> 4 );
			} else {
				up[2*j+1][i] = ( ( - up[(j-1)*2][i] + 9 * up[(j)*2][i] + 9 * up[(j+1)*2][i] - up[(j+2)*2][i] + 8 ) >> 4 );
			}
		}
	}

}


static void upsample2x1_to_2x2(int **up, int **y, int w_small, int h_small) {
	int i,j;
	// y and up should be allocated externally
	// y :  dim is w_small * h_small
	// up : dim is (w_small*2) * (h_small*2)
	// -------------------------------------------------

	// For the upsampling algorithm, see doc JVT-I019     ftp://ftp3.itu.ch/av-arch/jvt-site/2003_09_SanDiego/JVT-I019.doc
	// Here we use the same filter for horiz and vert, since it keep the original values of pixels in half the positions

	// Output samples can be produced at positions 0..2N-1 for input samples at positions, 0..N-1, as follows.
	//
	// Samples at positions 2n are generated (x=0) as
	// y[n].
	// Samples at positions 2n+1 except positions 1, 2N-3 and 2N-1 are generated (x=1/2) as
	// ( - y[n-1] + 9 * y[n] + 9 * y[n+1] - y[n+2] + 8 ) >> 4.
	// Samples at position 1 are generated (interpolation, x= -1/2) as
	// ( 6 * y[0] + 12 * y[1] - 2 * y[2] + 8 ) >> 4.
	// Samples at position 2N-3 are generated (interpolation, x=1/2) as
	// ( - 2 * y[N-3] + 12 * y[N-2] + 6 * y[N-1] + 8 ) >> 4.
	// Samples at position 2N-1 are generated (extrapolation, x=1/2) as
	// ( 4 * y[N-3] - 16 * y[N-2] + 28 * y[N-1] + 8 ) >> 4.

	// Horizontal upsampling
	for (j=0; j<h_small; j++) {
		for (i=0; i<w_small; i++) {
			up[j][2*i] = y[j][i];
			if (i==0) {
				up[j][2*i+1] = ( ( 6 * y[j][0] + 12 * y[j][1] - 2 * y[j][2] + 8 ) >> 4 );
			} else if (i==w_small-2) {
				int N = w_small;
				up[j][2*i+1] = ( ( -2 * y[j][N-3] + 12 * y[j][N-2] + 6 * y[j][N-1] + 8 ) >> 4 );
			} else if (i==w_small-1) {
				int N = w_small;
				up[j][2*i+1] = ( ( 4 * y[j][N-3] - 16 * y[j][N-2] + 28 * y[j][N-1] + 8 ) >> 4 );
			} else {
				up[j][2*i+1] = ( ( - y[j][i-1] + 9 * y[j][i] + 9 * y[j][i+1] - y[j][i+2] + 8 ) >> 4 );
			}
		}
	}
}


img444_t *upsample411_444_asH264(imgYUV_t *in) {
	int i,j;
	int M = in->size.w;
	int N = in->size.h;
	img444_t *out;
	int **m_small;
	int **m_large;
	
	out = create_img444(in->size.w, in->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[0][j][i] = (val_t)(unsigned int) in->Y[j*M+i];
		}
	}

	m_small = alloc_int2D(M/2, N/2);
	m_large = alloc_int2D(M, N);

	for (j=0; j<N/2; j++) {
		for (i=0; i<M/2; i++) {
			m_small[j][i] = (int)(unsigned int) in->U[j*M/2+i];
		}
	}
	upsample1x1_to_2x2(m_large, m_small, M/2, N/2);
	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[1][j][i] = (val_t)m_large[j][i];
		}
	}
	
	for (j=0; j<N/2; j++) {
		for (i=0; i<M/2; i++) {
			m_small[j][i] = (int)(unsigned int) in->V[j*M/2+i];
		}
	}
	upsample1x1_to_2x2(m_large, m_small, M/2, N/2);
	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[2][j][i] = (val_t)m_large[j][i];
		}
	}
	
	free_int2D(m_small, N/2);
	free_int2D(m_large, N);

	return out;
}

img444i_t *upsampleYUV_444i_asH264(imgYUV_t *in) {
	if (in->format == YUV_420) {
		return upsample420_444i_asH264(in);
	} else if (in->format == YUV_422) {
		return upsample422_444i_asH264(in);
	} else {
		fprintf(stderr,"444->444 upsampling not yet implemented\n"); exit(1);
	}
}


static img444i_t *upsample420_444i_asH264(imgYUV_t *in) {
	int i,j;
	int M = in->size.w;
	int N = in->size.h;
	img444i_t *out;
	int **m_small;
	int **m_large;
	
	out = create_img444i(in->size.w, in->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[0][j][i] = (int)(unsigned int) in->Y[j*M+i];
		}
	}

	m_small = alloc_int2D(M/2, N/2);
	m_large = alloc_int2D(M, N);

	for (j=0; j<N/2; j++) {
		for (i=0; i<M/2; i++) {
			m_small[j][i] = (int)(unsigned int) in->U[j*M/2+i];
		}
	}
	upsample1x1_to_2x2(m_large, m_small, M/2, N/2);
	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[1][j][i] = (int)m_large[j][i];
		}
	}
	
	for (j=0; j<N/2; j++) {
		for (i=0; i<M/2; i++) {
			m_small[j][i] = (int)(unsigned int) in->V[j*M/2+i];
		}
	}
	upsample1x1_to_2x2(m_large, m_small, M/2, N/2);
	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[2][j][i] = (int)m_large[j][i];
		}
	}
	
	free_int2D(m_small, N/2);
	free_int2D(m_large, N);

	return out;
}


static img444i_t *upsample422_444i_asH264(imgYUV_t *in) {
	int i,j;
	int M = in->size.w;
	int N = in->size.h;
	img444i_t *out;
	int **m_small;
	int **m_large;
	
	out = create_img444i(in->size.w, in->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[0][j][i] = (int)(unsigned int) in->Y[j*M+i];
		}
	}

	m_small = alloc_int2D(M/2, N);
	m_large = alloc_int2D(M, N);

	for (j=0; j<N; j++) {
		for (i=0; i<M/2; i++) {
			m_small[j][i] = (int)(unsigned int) in->U[j*M/2+i];
		}
	}
	upsample2x1_to_2x2(m_large, m_small, M/2, N);
	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[1][j][i] = (int)m_large[j][i];
		}
	}
	
	for (j=0; j<N; j++) {
		for (i=0; i<M/2; i++) {
			m_small[j][i] = (int)(unsigned int) in->V[j*M/2+i];
		}
	}
	upsample2x1_to_2x2(m_large, m_small, M/2, N);
	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[2][j][i] = (int)m_large[j][i];
		}
	}
	
	free_int2D(m_small, N);
	free_int2D(m_large, N);

	return out;
}

// #################################################
//  PVQM Computation
// #################################################


img444i_t * A1i_horizontal_filter(img444i_t *in) {
	int i,j,c;
	int M = in->size.w;
	int N = in->size.h;
	img444i_t *out;

	out = create_img444i(in->size.w, in->size.h);

	for (c=0; c<3; c++) {
		for (j=0; j<N; j++) {
			out->P[c][j][0] = in->P[c][j][0];
			out->P[c][j][M-1] = in->P[c][j][M-1];
		}
		for (j=0; j<N; j++) {
			for (i=1; i<M-1; i++) {
				//    /4  is equivalent to  >> 2 ;
				out->P[c][j][i] = (in->P[c][j][i-1] + (in->P[c][j][i] << 1) + in->P[c][j][i+1]) >> 2;
			}
		}
	}
	return out;
}


img444i_t * A2i_field_separation(img444i_t *in) {
	int i,j,c;
	int M = in->size.w;
	int N = in->size.h;
	img444i_t *out;

	out = create_img444i(in->size.w, in->size.h);

	for (c=0; c<3; c++) {
		for (j=0; j<N/2; j++) {
			for (i=0; i<M; i++) {
				out->P[c][j][i] = in->P[c][j*2][i];
			}
		}
		for (j=0; j<N/2; j++) {
			for (i=0; i<M; i++) {
				out->P[c][N/2+j][i] = in->P[c][j*2+1][i];
			}
		}
	}
	return out;
}





//Speedup
img1c_t * A31i_edginess(img444i_t *in, int interlaced) {
	int i,j;
	//int c;
	int M = in->size.w;
	int N = in->size.h;
	////int hor, vert;
	val_t hor, vert;
	//val_t edge;
	img1c_t *out;

	out = create_img1c(in->size.w, in->size.h);

	if (interlaced) {
		for (j=1; j<N/2-1; j++) {
			for (i=2; i<M-2; i++) {
				hor = (in->P[0][j][i+2] + in->P[0][j][i+1] - in->P[0][j][i-1] - in->P[0][j][i-2]) >> 1;
				vert = (in->P[0][j+1][i] - in->P[0][j-1][i]);
				out->P[j][i] = SQRT((val_t)(hor*hor+vert*vert));
			}
		}
		for (j=N/2+1; j<N-1; j++) {
			for (i=2; i<M-2; i++) {
				hor = (in->P[0][j][i+2] + in->P[0][j][i+1] - in->P[0][j][i-1] - in->P[0][j][i-2]) >> 1;
				vert = (in->P[0][j+1][i] - in->P[0][j-1][i]);
				out->P[j][i] = SQRT((val_t)(hor*hor+vert*vert));
			}
		}
		j=0;
		for (i=2; i<M-2; i++) { out->P[j][i] = 0; }
		j=N/2-1;
		for (i=2; i<M-2; i++) { out->P[j][i] = 0; }
		j=N/2;
		for (i=2; i<M-2; i++) { out->P[j][i] = 0; }
		j=N-1;
		for (i=2; i<M-2; i++) { out->P[j][i] = 0; }

		for (j=0; j<N; j++) { out->P[j][0] = 0; out->P[j][1] = 0; }
		for (j=0; j<N; j++) { out->P[j][M-1] = 0; out->P[j][M-2] = 0; }
	} else {
		// FIXME: Check the extreme values of the indexes !!!
		for (j=1; j<N-1; j++) {
			for (i=2; i<M-2; i++) {
				hor = (in->P[0][j][i+2] + in->P[0][j][i+1] - in->P[0][j][i-1] - in->P[0][j][i-2]) >> 1;
				vert = (in->P[0][j+1][i] - in->P[0][j-1][i]);
				out->P[j][i] = SQRT((val_t)(hor*hor+vert*vert));
			}
		}
		j=0;
		for (i=2; i<M-2; i++) { out->P[j][i] = 0; }
		j=N-1;
		for (i=2; i<M-2; i++) { out->P[j][i] = 0; }

		for (j=0; j<N; j++) { out->P[j][0] = 0; out->P[j][1] = 0; }
		for (j=0; j<N; j++) { out->P[j][M-1] = 0; out->P[j][M-2] = 0; }
	}
	return out;
}


// Speedup
img1c_t * A32_dilation_edginess(img1c_t *in) {
	int i,j;
	//int k;
	int M = in->size.w;
	int N = in->size.h;
	img1c_t *out;
	val_t max;

	out = create_img1c(in->size.w, in->size.h);

	for (j=1; j<N-1; j++) {
		for (i=1; i<M-1; i++) {
			max = in->P[j][i];
			if (in->P[j-1][i-1] > max) { max = in->P[j-1][i-1]; }
			if (in->P[j-1][i] > max) { max = in->P[j-1][i]; }
			if (in->P[j-1][i+1] > max) { max = in->P[j-1][i+1]; }
			if (in->P[j][i-1] > max) { max = in->P[j][i-1]; }
			if (in->P[j][i+1] > max) { max = in->P[j][i+1]; }
			if (in->P[j+1][i-1] > max) { max = in->P[j+1][i-1]; }
			if (in->P[j+1][i] > max) { max = in->P[j+1][i]; }
			if (in->P[j+1][i+1] > max) { max = in->P[j+1][i+1]; }
			out->P[j][i] = max;
		}
	}

	for (j=1; j<N-1; j++) {
		i=0;
		max = in->P[j][i];
		if (in->P[j-1][i] > max) { max = in->P[j-1][i]; }
		if (in->P[j-1][i+1] > max) { max = in->P[j-1][i+1]; }
		if (in->P[j][i+1] > max) { max = in->P[j][i+1]; }
		if (in->P[j+1][i] > max) { max = in->P[j+1][i]; }
		if (in->P[j+1][i+1] > max) { max = in->P[j+1][i+1]; }
		out->P[j][i] = max;
	}
	for (j=1; j<N-1; j++) {
		i=M-1;
		max = in->P[j][i];
		if (in->P[j-1][i-1] > max) { max = in->P[j-1][i-1]; }
		if (in->P[j-1][i] > max) { max = in->P[j-1][i]; }
		if (in->P[j][i-1] > max) { max = in->P[j][i-1]; }
		if (in->P[j+1][i-1] > max) { max = in->P[j+1][i-1]; }
		if (in->P[j+1][i] > max) { max = in->P[j+1][i]; }
		out->P[j][i] = max;
	}
	j=0;	
	for (i=1; i<M-1; i++) {
		max = in->P[j][i];
		if (in->P[j][i-1] > max) { max = in->P[j][i-1]; }
		if (in->P[j][i+1] > max) { max = in->P[j][i+1]; }
		if (in->P[j+1][i-1] > max) { max = in->P[j+1][i-1]; }
		if (in->P[j+1][i] > max) { max = in->P[j+1][i]; }
		if (in->P[j+1][i+1] > max) { max = in->P[j+1][i+1]; }
		out->P[j][i] = max;
	}
	j=N-1;	
	for (i=1; i<M-1; i++) {
		max = in->P[j][i];
		if (in->P[j-1][i-1] > max) { max = in->P[j-1][i-1]; }
		if (in->P[j-1][i] > max) { max = in->P[j-1][i]; }
		if (in->P[j-1][i+1] > max) { max = in->P[j-1][i+1]; }
		if (in->P[j][i-1] > max) { max = in->P[j][i-1]; }
		if (in->P[j][i+1] > max) { max = in->P[j][i+1]; }
		out->P[j][i] = max;
	}
	j=0;
	i=0;
	max = in->P[j][i];
	if (in->P[j][i+1] > max) { max = in->P[j][i+1]; }
	if (in->P[j+1][i] > max) { max = in->P[j+1][i]; }
	if (in->P[j+1][i+1] > max) { max = in->P[j+1][i+1]; }
	out->P[j][i] = max;
	j=N-1;
	i=0;
	max = in->P[j][i];
	if (in->P[j-1][i] > max) { max = in->P[j-1][i]; }
	if (in->P[j-1][i+1] > max) { max = in->P[j-1][i+1]; }
	if (in->P[j][i+1] > max) { max = in->P[j][i+1]; }
	out->P[j][i] = max;
	j=N-1;
	i=M-1;
	max = in->P[j][i];
	if (in->P[j-1][i-1] > max) { max = in->P[j-1][i-1]; }
	if (in->P[j-1][i] > max) { max = in->P[j-1][i]; }
	if (in->P[j][i-1] > max) { max = in->P[j][i-1]; }
	out->P[j][i] = max;
	j=0;
	i=M-1;
	max = in->P[j][i];
	if (in->P[j][i-1] > max) { max = in->P[j][i-1]; }
	if (in->P[j+1][i-1] > max) { max = in->P[j+1][i-1]; }
	if (in->P[j+1][i] > max) { max = in->P[j+1][i]; }
	out->P[j][i] = max;

	return out;
}


img1c_t * A33_max_dev_mid_range_luminance(img1c_t *orig, img1c_t *err) {
	int i,j;
	int M = orig->size.w;
	int N = orig->size.h;
	img1c_t *out;

	out = create_img1c(orig->size.w, orig->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			val_t diff_orig, diff_err;
			if (orig->P[j][i] - 100 > 0.0) diff_orig = orig->P[j][i] - 100; else diff_orig =  -( orig->P[j][i] - 100);
			if (err->P[j][i] - 100 > 0.0) diff_err = err->P[j][i] - 100; else diff_err =  -(err->P[j][i] - 100);
			out->P[j][i] = MAX(diff_orig, diff_err);
		}
	}
	if (debug) { print_stat_img1c("A33_max_dev_mid_range_luminance", out); }
	return out;
}


img1c_t * A34_normalized_change_edginess(img1c_t *x, img1c_t *y, img1c_t *dev) {
	int i,j;
	int M = dev->size.w;
	int N = dev->size.h;
	img1c_t *out;

	out = create_img1c(dev->size.w, dev->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			if (y->P[j][i] != x->P[j][i]) {
				if ( x->P[j][i] + 80 + dev->P[j][i] == 0.0 ) {
					//if (debug) { fprintf(stderr, "DEBUG: denominator in A34 = 0, numerator = "PS"\n",y->P[j][i]-x->P[j][i]); exit(2); }
					// V6: +40 or -40 depending on the y-x sign
					if (y->P[j][i] - x->P[j][i] > 0.0) {
						out->P[j][i] = 40; // This is anyway clipped to +40 in A35 stage . Limit value to be able to plot it (in debug YUV)
					} else {
						out->P[j][i] = -40; // This is anyway clipped to -40 in A35 stage . Limit value to be able to plot it (in debug YUV)
					}
				} else {
					out->P[j][i] = (y->P[j][i] - x->P[j][i]) / ( x->P[j][i] + 80 + dev->P[j][i] );
					// FIXME: this has been modified to keep it coherent - see also other points in the code with FACTOR
					out->P[j][i] *= FACTOR;
					if ( isnan (out->P[j][i]) ) {
						fprintf(stderr, "ERROR: Internal error: isnan = true! - A34 - j=%d i=%d\n",j,i); exit(2);
					}
				}
			} else {
				out->P[j][i] = 0.0;
			}
		}
	}
	if (debug) { print_stat_img1c("A34_normalized_change_edginess", out); }
	return out;
}


img1c_t * A35_clipping_normalized_change_edginess(img1c_t *in) {
	int i,j;
	int M = in->size.w;
	int N = in->size.h;
	img1c_t *out;

	out = create_img1c(in->size.w, in->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			if (in->P[j][i] < -40)
				out->P[j][i] = -40;
			else if (in->P[j][i] > 40)
				out->P[j][i] = 40;
			else
				out->P[j][i] = in->P[j][i];
		}
	}
	return out;
}

void precompute_weight_function_if_needed(int wi, int he, int interlaced) {
	int i,j;
	//img1c_t *out;
	int N,M;
	N=he; M=wi;
	if (!W) {
		W = create_img1c(wi,he);
		if (!interlaced) {
			for (j=0; j<N; j++) {
				for (i=0; i<M; i++) {
					W->P[j][i] = sin(M_PI*i/M)*ABS(sin(M_PI*j/N));
				}
			}	
		} else {
			for (j=0; j<N; j++) {
				for (i=0; i<M; i++) {
					W->P[j][i] = sin(M_PI*i/M)*ABS(sin(M_PI*j*2/N));
				}
			}	
		}
	}
}

val_t A36_A37_aggregation_over_fields(img1c_t *in, region_t *r, int interlaced) {
	int i,j;
	int M = in->size.w;
	int N = in->size.h;
	val_t sum, sumw, v;
	val_t e_aggregfield;

	precompute_weight_function_if_needed(in->size.w, in->size.h, interlaced);

	if (interlaced) {
		field_t *out;
		out = (field_t *)malloc(sizeof(field_t));
		if (!out) { fprintf(stderr,"ERROR: Cannot create field_t\n"); exit(1); }

		sum = 0.0;
		sumw = 0.0;
		for (j=r->T/2; j<(N-(r->B))/2; j++) {
			for (i=r->L; i<M-(r->R); i++) {
				v = in->P[j][i];
				sum += ( ABS(v*v*v*v*v*v*v) * W->P[j][i] );
				sumw += W->P[j][i];
			}
		}
		//if (debug) printf("sum="PS" sumw="PS"\n",sum,sumw);
		out->top = POW ( sum/sumw , 1.0/7.0 );

		sum = 0.0;
		sumw = 0.0;
		for (j=(N+r->T)/2; j<N-((r->B)/2); j++) {
			for (i=r->L; i<M-(r->R); i++) {
				v = in->P[j][i];
				sum += ( ABS(v*v*v*v*v*v*v) * W->P[j][i] );
				sumw += W->P[j][i];
			}
		}
		out->bot = POW ( sum/sumw , 1.0/7.0 );
		e_aggregfield = (out->top + out->bot) / 2.0;
		free(out);
	} else {
		sum = 0.0;
		sumw = 0.0;
		for (j=r->T; j<(N-(r->B)); j++) {
			for (i=r->L; i<M-(r->R); i++) {
				v = in->P[j][i];
				sum += ( ABS(v*v*v*v*v*v*v) * W->P[j][i] );
				sumw += W->P[j][i];
			}
		}
		//if (debug) printf("sum="PS" sumw="PS"\n",sum,sumw);
		e_aggregfield = POW ( sum/sumw , 1.0/7.0 );
	}

	return e_aggregfield;
}



val_t A4i_temporal_decorrelation_indicator(img444i_t *in_t, img444i_t *in_t_1, region_t *r, int interlaced) {
	int i,j;
	int M = in_t->size.w;
	int N = in_t->size.h;
	val_t sump, sum2t, sum2t1;
	val_t sq_sum2t, sq_sum2t1;
	val_t d;

	sump = 0.0;
	sum2t = 0.0;
	sum2t1 = 0.0;

	if (interlaced) {
		for (j=r->T/2; j<(N-(r->B))/2; j++) {
			for (i=r->L; i<M-(r->R); i++) {
				sump += (val_t) ( in_t->P[0][j][i] * in_t_1->P[0][j][i] );
				sum2t += (val_t) ( in_t->P[0][j][i] * in_t->P[0][j][i] );
				sum2t1 += (val_t) ( in_t_1->P[0][j][i] * in_t_1->P[0][j][i] );
			}
		}
		for (j=(N+r->T)/2; j<N-((r->B)/2); j++) {
			for (i=r->L; i<M-(r->R); i++) {
				sump += (val_t) ( in_t->P[0][j][i] * in_t_1->P[0][j][i] );
				sum2t += (val_t) ( in_t->P[0][j][i] * in_t->P[0][j][i] );
				sum2t1 += (val_t) ( in_t_1->P[0][j][i] * in_t_1->P[0][j][i] );
			}
		}
	} else {
		// V6: Added case NOT interlaced
		for (j=r->T; j<(N-(r->B)); j++) {
			for (i=r->L; i<M-(r->R); i++) {
				sump += ( in_t->P[0][j][i] * in_t_1->P[0][j][i] );
				sum2t += ( in_t->P[0][j][i] * in_t->P[0][j][i] );
				sum2t1 += ( in_t_1->P[0][j][i] * in_t_1->P[0][j][i] );
			}
		}
	}
	//if (debug) { printf("INFO: sump="PS" sum2t="PS" sum2t1="PS"\n", sump, sum2t, sum2t1); }

	//d = 1.0 - ( sump / (sum2t*sum2t1) );
	//sq_sum2t = sum2t; sq_sum2t1 = sum2t1;
	sq_sum2t = SQRT(sum2t);    // NB: This is needed to normalize the result between 0 and 1  (otherwise d is always =0 or =1)
	sq_sum2t1 = SQRT(sum2t1);  //     It should be an inner (or dot) product as explained in the paper
	if (debug) { printf("INFO: sump="PS" sq_sum2t="PS" sq_sum2t1="PS"\n", sump, sq_sum2t, sq_sum2t1); }
	d = ( sq_sum2t*sq_sum2t1 - sump ) / (sq_sum2t*sq_sum2t1);
	// email from the authors (andries.hekstra@nxp.com, May 23, 2008)
	d = d * FACTOR;
	return d;
}


img1c_t * A51i_maximum_color_saturation(img444i_t *orig, img444i_t *dec) {
	int i,j;
	int M = orig->size.w;
	int N = orig->size.h;
	img1c_t *out;
	val_t sat_x, sat_y, sat;

	out = create_img1c(orig->size.w, orig->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			sat_x = SQRT( (val_t) ((orig->P[1][j][i] - 128) * (orig->P[1][j][i] - 128) + (orig->P[2][j][i] - 128) * (orig->P[2][j][i] - 128)) );
			sat_y = SQRT( (val_t) ((dec->P[1][j][i]  - 128) * (dec->P[1][j][i]  - 128) + (dec->P[2][j][i]  - 128) * (dec->P[2][j][i]  - 128)) );
			sat = MAX(sat_x, sat_y);
			out->P[j][i] = sat;
		}
	}
	if (debug) { print_stat_img1c("A51i_maximum_color_saturation", out); }
	return out;
}



img444_t * A52i_normalized_color_error(img444i_t *orig, img444i_t *dec, img1c_t *sat) {
	int i,j,c;
	int M = orig->size.w;
	int N = orig->size.h;
	img444_t *out;

	out = create_img444(orig->size.w, orig->size.h);

	for (j=0; j<N; j++) {
		for (i=0; i<M; i++) {
			out->P[0][j][i] = 0.0;   // Reset unused (Y) values
		}
	}
	for (c=1; c<3; c++) {
		for (j=0; j<N; j++) {
			for (i=0; i<M; i++) {
				val_t abs_d;
				int d;
				d = dec->P[c][j][i] - orig->P[c][j][i];
				// C'era un bug in molte versioni precedenti: non si prendeva abs_d nell'ultima formula!! Now is ok.
				if (d > 0) abs_d = (val_t)d; else abs_d = (val_t)(-d);
				out->P[c][j][i] = abs_d / (25 + 0.3 * sat->P[j][i]);
			}
		}
	}
	return out;
}


indic3c_t * A53_A54_aggregation_over_fields(img444_t *in, region_t *r, int interlaced) {
	int i,j,c;
	int M = in->size.w;
	int N = in->size.h;
	val_t sum, sumw, v;
	indic3c_t *out;

	precompute_weight_function_if_needed(in->size.w, in->size.h, interlaced);

	out = (indic3c_t *)malloc(sizeof(indic3c_t));
	if (!out) { fprintf(stderr,"ERROR: Cannot create indic3c_t\n"); exit(1); }

	out->v[0] = 0.0;  // Reset unused (Y) value

	if (interlaced) {
		field3c_t *part_out;
		part_out = (field3c_t *)malloc(sizeof(field3c_t));
		if (!part_out) { fprintf(stderr,"ERROR: Cannot create field3c_t\n"); exit(1); }

		part_out->top[0]=0.0;  // Reset unused (Y) value
		part_out->bot[0]=0.0;  // Reset unused (Y) value

		sum = 0.0;
		sumw = 0.0;
		for (c=1; c<3; c++) {   // Only for colors:  start at c=1
			for (j=r->T/2; j<(N-(r->B))/2; j++) {
				for (i=r->L; i<M-(r->R); i++) {
					v = in->P[c][j][i];
					sum += ( (v*v) * W->P[j][i] );
					sumw += W->P[j][i];
				}
			}
			part_out->top[c] = SQRT ( sum/sumw );
		}

		sum = 0.0;
		sumw = 0.0;
		for (c=1; c<3; c++) {   // Only for colors:  start at c=1
			for (j=(N+r->T)/2; j<N-((r->B)/2); j++) {
				for (i=r->L; i<M-(r->R); i++) {
					v = in->P[c][j][i];
					sum += ( (v*v) * W->P[j][i] );
					sumw += W->P[j][i];
				}
			}
			part_out->bot[c] = SQRT ( sum/sumw );
		}

		for (c=1; c<3; c++) {   // Only for colors:  start at c=1
			out->v[c] = MIN( part_out->top[c], part_out->bot[c] );

			// FIXME: this has been modified to keep it coherent - see also other points in the code with FACTOR
			out->v[c] *= FACTOR;
		}
		free(part_out);
	} else {
		sum = 0.0;
		sumw = 0.0;
		for (c=1; c<3; c++) {   // Only for colors:  start at c=1
			for (j=r->T; j<(N-(r->B)); j++) {
				for (i=r->L; i<M-(r->R); i++) {
					v = in->P[c][j][i];
					sum += ( (v*v) * W->P[j][i] );
					sumw += W->P[j][i];
				}
			}
			out->v[c] = SQRT ( sum/sumw );

			// FIXME: this has been modified to keep it coherent - see also other points in the code with FACTOR
			out->v[c] *= FACTOR;
		}
	}

	return out;
}


val_t A61_seq_aggr_luminance_edginess(val_t *v_e, int P) {
	//int t;
	//val_t sum, v;
	val_t E, EI;

	E = A61_NOCLIP_seq_aggr_luminance_edginess(v_e, P);
	EI = A61_CLIP(E);

	return EI;
}


val_t A61_NOCLIP_seq_aggr_luminance_edginess(val_t *v_e, int P) {
	int t;
	val_t sum, v;
	val_t E;

	sum = 0.0;
	for (t=0; t<P; t++) {
		v = v_e[t];
		sum += ( v*v*v*v*v*v*v );
	}
	if (sum < 0) { fprintf(stderr,"ERROR: Internal error: sum < 0 (need to ^1/7)\n"); exit(2); }
	E = POW ( sum/P , 1.0/7.0 );
	
	if (debug) { printf("INFO: sum/P = "PE", 7-root: E = "PS", now clipping to 7\n", sum/P, E); }

	return E;
}

val_t A61_CLIP(val_t E) {
	val_t EI;
	if (E < 7)
		EI = 0;
	else
		EI = E - 7.0;
	return EI;
}


val_t A62_seq_aggr_decorrelation(val_t *v_d, int P_1) {
	int t;
	val_t sum, v;
	val_t D;

	sum = 0.0;
	for (t=1; t<=P_1; t++) {   // NB: Different from previous (because of number of elements and divisor)
		v = v_d[t];
		sum += ( v*v*v*v*v*v*v );
	}
	if (sum < 0) { fprintf(stderr,"ERROR: Internal error: sum < 0 (need to ^1/7)\n"); exit(2); }

	D = POW ( sum/P_1 , 1.0/7.0 );
	if (debug) { printf("INFO: sum/P_1 = "PE", 7-root: D = "PS"\n", sum/P_1, D); }
	return D;
}

indic3c_t *A63_seq_aggr_color_indicators(indic3c_t *v_n, int P_1) {
	int c,t;
	val_t sum, v;
	//val_t D;
	indic3c_t *out;

	out = (indic3c_t *)malloc(sizeof(indic3c_t));
	if (!out) { fprintf(stderr,"ERROR: Cannot create indic3c_t\n"); exit(1); }

	out->v[0] = 0.0;
	for (c=1; c<3; c++) {  // start at c=1
		sum = 0.0;
		//for (t=1; t<=P_1+1; t++) 
		//email from the authors (andries.hekstra@nxp.com, May 23, 2008)
		for (t=0; t<P_1+1; t++) {
			v = v_n[t].v[c];
			//sum += ( v*v*v*v*v*v*v );
			//email from the authors (andries.hekstra@nxp.com, May 23, 2008)
			sum += ( v );
		}
		//if (sum < 0) { fprintf(stderr,"ERROR: Internal error: sum < 0 (need to ^1/7)\n"); exit(2); }
		//out->v[c] = POW ( sum/P_1 , 1.0/7.0 );
		//email from the authors (andries.hekstra@nxp.com, May 23, 2008)
		out->v[c] = sum/(P_1+1);
	}
	return out;
}

val_t A64_predicted_DMOS(val_t EI, indic3c_t *N, val_t D) {
	val_t dmos_p, dmos_pI;

	dmos_p = A64_NOCLIP_predicted_DMOS(EI, N, D);
	dmos_pI = A64_CLIP(dmos_p);

	return dmos_pI;
}


val_t A64_NOCLIP_predicted_DMOS(val_t EI, indic3c_t *N, val_t D) {
	val_t dmos_p;

	dmos_p = 3.95 * EI + 0.74 * N->v[2] - 0.78 * D - 0.4;

	if (debug) { printf("INFO: dmos_p: "PS" (before clipping 0-85)\n", dmos_p); }

	return dmos_p;
}

val_t A64_CLIP(val_t dmos_p) {
	val_t dmos_pI;

	if (dmos_p < 0)
		dmos_pI = 0;
	else if (dmos_p > 85)
		dmos_pI = 85;
	else
		dmos_pI = dmos_p;

	return dmos_pI;
}


