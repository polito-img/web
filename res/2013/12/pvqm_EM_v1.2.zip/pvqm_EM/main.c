/*
 * This file is part of pvqm_EM
 *
 * Copyright (C) 2014  Enrico Masala
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Enrico Masala   < masala _at-symbol_ polito dot it >
 *
 * The software has been written from scratch following the description in:
 * A.P. Hekstraa, J.G. Beerendsa, et al., "PVQM - A Perceptual Video Quality Measure", Signal Processing: Image Communication, vol. 17, n. 10, Nov 2002, pp. 781 - 798.
 *
 * Please note that the license of this software does not give you any additional rights regarding patents
 * that might cover algorithms implemented in this software. Please consult a professional in case you need advice.
 *
 * The software is available to the research community free of charge.
 * If you wish to use this software in your research, we kindly ask that you reference our papers listed below:
 *
 * Marcus Barkowsky, Enrico Masala, Glenn Van Wallendael, Kjell Brunnstrom, Nicolas Staelens, and Patrick Le Callet,
 * "Objective Video Quality Assessment - Towards large scale video database enhanced model development",
 * IEICE Transactions on Communications, Jan 2015 (accepted for publication)
 * (please update the citation information once the manuscript will be published)
 *
 * Further citation information, downloads, etc., can be found at:
 * http://media.polito.it/jeg
 *
 */

#ifdef _WIN32
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/stat.h>
//#include <unistd.h>

#include "tools.h"
#include "pvqm.h"

//#define DEBUG

static char strVERSION[]="1.2";
static char strNAME[]="PVQM";

void print_usage(char **argv) {
	fprintf(stderr,"\n%s Implementation by Enrico Masala, 2014\n"
			"v. %s\n"
			"\n"
			"The implementation follows the description of\n"
			"A.P. Hekstraa, J.G. Beerendsa, et al., \n"
			"\"PVQM - A Perceptual Video Quality Measure\",\n"
			"Signal Processing: Image Communication, \n"
			"vol. 17, n. 10, Nov 2002, pp. 781-798\n"
			"\n"
			"Usage: %s  refVideo procVideo h w format outFile\n"
			"\n"
			"format: YUV420 or YUV422\n"
			"\n",strNAME,strVERSION,argv[0]);
	fprintf(stderr,"Example:\n"
			"%s referenceVideo.yuv processedVideo.yuv 144 176 YUV420 result\n"
			"\n"
			"The number of frames will be automatically computed\n"
			"A result_pvqm.csv file will be produced\n"
			"\n", argv[0]
	       );
}


int main(int argc, char *argv[]) {

	FILE *fin1=NULL;
	FILE *fin2=NULL;
	FILE *fin_reference=NULL;
	FILE *fin_processed=NULL;
	int start_num, analyze_num;
	//int start_second_list;

	int continue_reference=0;
	int start_reference=0;

	//char auxname[1024];
	//char auxname1[1024];

	

	//int len;

	pvqm_input_t inp;

	file_out_t file_out;

	int width, height;
	int num;
#ifdef _WIN32
	__int64 flen_reference, flen_processed, flen_min, frame_len;
#else
	int flen_reference, flen_processed, flen_min, frame_len;
	struct stat statbuf;
#endif
	int flen_dec = 0;
	int silent = 0;
	int pidx;
	char *basename;
	char *fname_reference;
	char *fname_processed;

	char *format;

	char fnameout[1024];

	pvqm_debug_t deb;
	pvqm_res_t res;
	val_t dmos_pi;


	if (argc!=7) {
		print_usage(argv);
		fprintf(stderr,"ERROR: Wrong number of parameters (%d)!\n\n", argc);
		exit(1);
	}


	inp.interlaced = 0;
	inp.file_format = FORMAT_YUV420;  // default
	inp.region.L = 0;
	inp.region.R = 0;
	inp.region.T = 0;
	inp.region.B = 0;


	
	pidx=1;
	fname_reference=argv[pidx];
	if((fin_reference=fopen(argv[pidx],"rb"))==NULL) {
		// Handles the case in which the file name is wrong
		fprintf(stderr,"Error opening input file %s\n",argv[pidx]);
		exit(1);
	}
	pidx++;


	fname_processed=argv[pidx];
	if((fin_processed=fopen(argv[pidx],"rb"))==NULL) {
		// Handles the case in which the file name is wrong
		fprintf(stderr,"Error opening input file %s\n",argv[pidx]);
		exit(1);
	}
	pidx++;

#ifdef _WIN32
	{
		struct _stat64 stbuf;
		_stat64(fname_reference, &stbuf);
		flen_reference = stbuf.st_size;
		_stat64(fname_processed, &stbuf);
		flen_processed = stbuf.st_size;
	}
#else
	fstat(fin_reference->_fileno, &statbuf);
	flen_reference = statbuf.st_size;
	fstat(fin_processed->_fileno, &statbuf);
	flen_processed = statbuf.st_size;
#endif

	height = atoi(argv[pidx]);	
	pidx++;
	width = atoi(argv[pidx]);
	pidx++;
	

	format = argv[pidx];
	pidx++;
	if (strncmp(format, "YUV420", 6)==0) {
		inp.file_format = FORMAT_YUV420;
	} else if (strncmp(format, "YUV422", 6)==0) {
		inp.file_format = FORMAT_YUV422;
	//} else if (strncmp(format, "YUV444", 6)==0) {
	//	inp.file_format = FORMAT_YUV444;
	} else {
		fprintf(stderr,"Error: format unknown: %s\n",format);
		exit(1);
	}
	
	basename=argv[pidx];	
	pidx++;

	strncpy(fnameout,basename,1024-10);
	strcat(fnameout,"_pvqm.csv");
	
	if ((file_out.fout_pvqm = fopen(fnameout,"w"))==NULL) {
		fprintf(stderr,"Error opening output file %s\n",fnameout);
		exit(1);
	}

	start_num=0;
	analyze_num=-1;
	//printf("start_num=%d\n", start_num);
	
	if (flen_reference != flen_processed && !silent) {
		printf("Warning: files to be compared (reference, processed) have different sizes (%d and %d)\n",
				flen_reference, flen_processed);
	}
	if (flen_reference > flen_processed) {
		flen_min=flen_processed;
	} else {
		flen_min=flen_reference;
	}
	

	if (inp.file_format == FORMAT_YUV420) {
		frame_len = (width*height + (width*height) / 2);
	} else if (inp.file_format == FORMAT_YUV422) {
		frame_len = (width*height)*2;
	//} else if (inp.file_format == FORMAT_YUV444) {
	//	frame_len = (width*height)*3;
	} else if (inp.file_format == FORMAT_UYVY) {
		frame_len = (width*height + (width*height));
	} else {
		fprintf(stderr,"Internal error: cannot understand value of inp.file_format (%d)\n", inp.file_format); exit(1);
	}
	num = (int)(flen_min / frame_len);

	printf("INFO: reference file size: %d\n", flen_reference);
	printf("INFO: frame_size (bytes): %d\n", frame_len);
	printf("INFO: number of frames to be analized: %d\n", num);


	fseek(fin_reference, (long)frame_len*start_num, SEEK_SET);
	fseek(fin_processed, (long)frame_len*start_num, SEEK_SET);

	inp.pic_n = num;
	if (inp.pic_n < 2) {
		fprintf(stderr,"ERROR: at least two frames must be analyzed\n"); exit(1);
	}

	deb.active = 0;
	//strncpy(deb.fnamebase, basename, 200);

	dmos_pi = compute_pvqm(fin_reference, fin_processed, width, height, &inp, &res, &file_out, &deb);
		
	fclose(fin_reference);
	fclose(fin_processed);

	fclose(file_out.fout_pvqm);

	printf("INFO: Done. DMOS_PI: "PS"\n", dmos_pi);
	
	return 0;
}

