/*
 * This file is part of pvqm_EM
 *
 * Copyright (C) 2014  Enrico Masala
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Enrico Masala   < masala _at-symbol_ polito dot it >
 *
 * The software has been written from scratch following the description in:
 * A.P. Hekstraa, J.G. Beerendsa, et al., "PVQM - A Perceptual Video Quality Measure", Signal Processing: Image Communication, vol. 17, n. 10, Nov 2002, pp. 781 - 798.
 *
 * Please note that the license of this software does not give you any additional rights regarding patents
 * that might cover algorithms implemented in this software. Please consult a professional in case you need advice.
 *
 * The software is available to the research community free of charge.
 * If you wish to use this software in your research, we kindly ask that you reference our papers listed below:
 *
 * Marcus Barkowsky, Enrico Masala, Glenn Van Wallendael, Kjell Brunnstrom, Nicolas Staelens, and Patrick Le Callet,
 * "Objective Video Quality Assessment - Towards large scale video database enhanced model development",
 * IEICE Transactions on Communications, Jan 2015 (accepted for publication)
 * (please update the citation information once the manuscript will be published)
 *
 * Further citation information, downloads, etc., can be found at:
 * http://media.polito.it/jeg
 *
 */

#ifndef __TOOLS_H_
#define __TOOLS_H_




typedef struct file_out_s {
	FILE *fout_pvqm;
} file_out_t;

typedef struct pic_size_s {
	int w;
	int h;
} pic_size_t;

typedef enum {YUV_420, YUV_422, YUV_444} yuv_t;
typedef enum {FORMAT_YUV420, FORMAT_YUV422, FORMAT_YUV444, FORMAT_UYVY} fileformat_t;

char *FileFormatToString(fileformat_t v);

typedef struct imgYUV_s {
	unsigned char *Y;
	unsigned char *U;
	unsigned char *V;
	pic_size_t size;
	yuv_t format;
} imgYUV_t;


void print_usage(char **argv);

void alloc_imgYUV(imgYUV_t *img, yuv_t type);
void free_imgYUV(imgYUV_t *img);

#endif
