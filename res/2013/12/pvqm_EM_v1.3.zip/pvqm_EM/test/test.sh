#!/bin/bash
../pvqm_EM foreman_part_qcif.yuv  foreman_part_qcif_coded.yuv 144 176 YUV420 test

diff test_pvqm.csv test_reference_pvqm.csv
if [ "$?" == "0" ]; then
	echo "TEST SUCCESSFUL"
else
	echo "TEST FAILED: please check difference between test_pvqm.csv and test_reference_pvqm.csv"
fi

